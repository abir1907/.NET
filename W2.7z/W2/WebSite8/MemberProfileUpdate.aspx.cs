﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using CMS_Project;

public partial class MemberProfileUpdate : System.Web.UI.Page
{
    string Member_Id = String.Empty;
    DataTable dataTableObject, nomineeTableObject, emailObject, insuranceObject;
    int numberOfNominees = 0;
    static int numNom = 0;
    string emailPrevious = String.Empty;
    static bool emailValidate = true;
    static List<string> nomineeIdList = new List<string>();
    string citizenType = String.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Admin_Id"] == null)
        {
            Response.Redirect("login.aspx");
        }
        if (!IsPostBack)
        {
            BindData();
        }
    }

    private void BindData()
    {
        using (Claim_Management_System dalObject = new Claim_Management_System())
        {
            if (Session["memberId"] != null)
            {
                Member_Id = Session["memberId"].ToString();
                adminidtextbox.Text = Session["Admin_Id"].ToString();
                memberidtextbox.Text = Member_Id;

                dataTableObject = dalObject.FunDataTable("select *, cast(Mem_Gender as varchar(1)) from members_profile where mem_id = @memberId", Member_Id);
                nomineeTableObject = dalObject.FunDataTable("select * from nominee_table where member_id = '" + Member_Id + "' order by Nominee_Id");
                insuranceObject = dalObject.FunDataTable("select i.* from insurance_type i inner join Members_Profile m on m.ins_type_id = i.type_id where m.mem_id = @memberId", Member_Id);

                if (dataTableObject.Rows.Count > 0)
                {
                    firstNameTextBox.Text = dataTableObject.Rows[0][1].ToString();
                    lastNameTextBox.Text = dataTableObject.Rows[0][2].ToString();
                    dateOfBirthTextBox.Text = dataTableObject.Rows[0][3].ToString().Split(' ')[0];
                    emailTextBox.Text = dataTableObject.Rows[0][8].ToString();
                    emailPrevious = dataTableObject.Rows[0][8].ToString();
                    phoneTextBox.Text = dataTableObject.Rows[0][7].ToString();
                    citizenType = dataTableObject.Rows[0][5].ToString();
                    addressTextArea.Text = dataTableObject.Rows[0][6].ToString();

                    nomineecombobox.Text = dataTableObject.Rows[0][9].ToString();
                    numberOfNominees = Convert.ToInt32(dataTableObject.Rows[0][9].ToString());
                    numNom = numberOfNominees;
                    insuranceTextBox.Text = insuranceObject.Rows[0][1].ToString();
                    insuredtextbox.Text = insuranceObject.Rows[0][2].ToString();
                    maxinsurancetextbox.Text = insuranceObject.Rows[0][3].ToString();

                    if (dataTableObject.Rows[0][12].ToString().Equals("M"))
                    {
                        Male.Checked = true;
                    }
                    else
                    {
                        Female.Checked = true;
                    }

                    switch (numNom)
                    {
                        case 1:
                            nomineecombobox.Text = "1";
                            nomineeDeleteButton1.Visible = false;
                            nomineeAddButton.Visible = true;
                            nominee1.Visible = true;
                            nominee2.Visible = false;
                            nominee3.Visible = false;

                            nomineeIdList.Clear();
                            nomineeIdList.Add(nomineeTableObject.Rows[0][0].ToString());

                            nomineefirstnametextbox1.Text = nomineeTableObject.Rows[0][1].ToString();
                            nomineelastnametextbox1.Text = nomineeTableObject.Rows[0][2].ToString();
                            dateofBirthCalender1.Text = nomineeTableObject.Rows[0][3].ToString().Split(' ')[0];
                            relationTextBox1.Text = nomineeTableObject.Rows[0][4].ToString();

                            if (nomineeTableObject.Rows[0][6].ToString().Equals("M"))
                            {
                                nomineemale1.Checked = true;
                            }
                            else
                            {
                                nomineefemale1.Checked = true;
                            }

                            break;
                        case 2:
                            nomineecombobox.Text = "2";
                            nomineeDeleteButton1.Visible = true;
                            nomineeAddButton.Visible = true;
                            nominee2.Visible = true;
                            nominee1.Visible = true;
                            nominee3.Visible = false;

                            nomineeIdList.Clear();
                            nomineeIdList.Add(nomineeTableObject.Rows[0][0].ToString());
                            nomineeIdList.Add(nomineeTableObject.Rows[1][0].ToString());

                            nomineefirstnametextbox1.Text = nomineeTableObject.Rows[0][1].ToString();
                            nomineelastnametextbox1.Text = nomineeTableObject.Rows[0][2].ToString();
                            dateofBirthCalender1.Text = nomineeTableObject.Rows[0][3].ToString().Split(' ')[0];
                            relationTextBox1.Text = nomineeTableObject.Rows[0][4].ToString();
                            nomineefirstnametextbox2.Text = nomineeTableObject.Rows[1][1].ToString();
                            nomineelastnametextbox2.Text = nomineeTableObject.Rows[1][2].ToString();
                            dateofBirthCalender2.Text = nomineeTableObject.Rows[1][3].ToString().Split(' ')[0];
                            relationTextBox2.Text = nomineeTableObject.Rows[1][4].ToString();

                            if (nomineeTableObject.Rows[0][6].ToString().Equals("M"))
                            {
                                nomineemale1.Checked = true;
                            }
                            else
                            {
                                nomineefemale1.Checked = true;
                            }

                            if (nomineeTableObject.Rows[1][6].ToString().Equals("M"))
                            {
                                nomineemale2.Checked = true;
                            }
                            else
                            {
                                nomineefemale2.Checked = true;
                            }

                            break;
                        case 3:
                            nomineecombobox.Text = "3";
                            nomineeDeleteButton1.Visible = true;
                            nomineeAddButton.Visible = false;
                            nominee3.Visible = true;
                            nominee1.Visible = true;
                            nominee2.Visible = true;

                            nomineeIdList.Clear();
                            nomineeIdList.Add(nomineeTableObject.Rows[0][0].ToString());
                            nomineeIdList.Add(nomineeTableObject.Rows[1][0].ToString());
                            nomineeIdList.Add(nomineeTableObject.Rows[2][0].ToString());

                            nomineefirstnametextbox1.Text = nomineeTableObject.Rows[0][1].ToString();
                            nomineelastnametextbox1.Text = nomineeTableObject.Rows[0][2].ToString();
                            dateofBirthCalender1.Text = nomineeTableObject.Rows[0][3].ToString().Split(' ')[0];
                            relationTextBox1.Text = nomineeTableObject.Rows[0][4].ToString();
                            nomineefirstnametextbox2.Text = nomineeTableObject.Rows[1][1].ToString();
                            nomineelastnametextbox2.Text = nomineeTableObject.Rows[1][2].ToString();
                            dateofBirthCalender2.Text = nomineeTableObject.Rows[1][3].ToString().Split(' ')[0];
                            relationTextBox2.Text = nomineeTableObject.Rows[1][4].ToString();
                            nomineefirstnametextbox3.Text = nomineeTableObject.Rows[2][1].ToString();
                            nomineelastnametextbox3.Text = nomineeTableObject.Rows[2][2].ToString();
                            dateofBirthCalender3.Text = nomineeTableObject.Rows[2][3].ToString().Split(' ')[0];
                            relationTextBox3.Text = nomineeTableObject.Rows[2][4].ToString();

                            if (nomineeTableObject.Rows[0][6].ToString().Equals("M"))
                            {
                                nomineemale1.Checked = true;
                            }
                            else
                            {
                                nomineefemale1.Checked = true;
                            }

                            if (nomineeTableObject.Rows[1][6].ToString().Equals("M"))
                            {
                                nomineemale2.Checked = true;
                            }
                            else
                            {
                                nomineefemale2.Checked = true;
                            }

                            if (nomineeTableObject.Rows[2][6].ToString().Equals("M"))
                            {
                                nomineemale3.Checked = true;
                            }
                            else
                            {
                                nomineefemale3.Checked = true;
                            }

                            break;
                    }
                }
            }
            else
            {
                Response.Redirect("login.aspx");
            }
        }
    }

    protected void updatememberButton_Click(object sender, EventArgs e)
    {
        using (Claim_Management_System dalObject = new Claim_Management_System())
        {
            if (emailValidate)
            {
                dalObject.FunExecuteNonQuery("update members_profile set Mem_No_Of_Nominees = " + nomineecombobox.Text + " where Mem_Id = '" + Session["memberId"].ToString() + "'");
                RegistrationPanel.Visible = false;
                newForm.Visible = true;

                dalObject.FunExecuteNonQuery("update members_profile set Mem_First_Name = '" + firstNameTextBox.Text + "', Mem_Last_Name = '" + lastNameTextBox.Text + "', Mem_DOB = '" + dateOfBirthTextBox.Text
                                                                   + "', Mem_Address = '" + addressTextArea.Text
                                                                   + "', Mem_Contact_No = '" + phoneTextBox.Text
                                                                   + "', Mem_Email_Id = '" + emailTextBox.Text
                                                                   + "', Mem_No_of_Nominees = " + nomineecombobox.Text
                                                                   + " where Mem_Id = '" + Session["memberId"].ToString() + "'");

                switch (Convert.ToInt32(nomineecombobox.Text))
                {
                    case 1:
                        dalObject.FunExecuteNonQuery("update nominee_table set Nominee_First_Name = '"
                                                    + nomineefirstnametextbox1.Text + "', Nominee_Last_Name = '"
                                                    + nomineelastnametextbox1.Text + "', Nominee_DOB = '"
                                                    + dateofBirthCalender1.Text + "', Nominee_Relation = '"
                                                    + relationTextBox1.Text + "' where Nominee_Id = '" + nomineeIdList[0] + "'");
                        break;
                    case 2:
                        dalObject.FunExecuteNonQuery("update nominee_table set Nominee_First_Name = '"
                                                     + nomineefirstnametextbox1.Text + "', Nominee_Last_Name = '"
                                                     + nomineelastnametextbox1.Text + "', Nominee_DOB = '"
                                                     + dateofBirthCalender1.Text + "', Nominee_Relation = '"
                                                     + relationTextBox1.Text + "' where Nominee_Id = '" + nomineeIdList[0] + "'");
                        dalObject.FunExecuteNonQuery("update nominee_table set Nominee_First_Name = '"
                                                    + nomineefirstnametextbox2.Text + "', Nominee_Last_Name = '"
                                                    + nomineelastnametextbox2.Text + "', Nominee_DOB = '"
                                                    + dateofBirthCalender2.Text + "', Nominee_Relation = '"
                                                    + relationTextBox2.Text + "' where Nominee_Id = '" + nomineeIdList[1] + "'");
                        break;
                    case 3:
                        dalObject.FunExecuteNonQuery("update nominee_table set Nominee_First_Name = '"
                                                    + nomineefirstnametextbox1.Text + "', Nominee_Last_Name = '"
                                                    + nomineelastnametextbox1.Text + "', Nominee_DOB = '"
                                                    + dateofBirthCalender1.Text + "', Nominee_Relation = '"
                                                    + relationTextBox1.Text + "' where Nominee_Id = '" + nomineeIdList[0] + "'");
                        dalObject.FunExecuteNonQuery("update nominee_table set Nominee_First_Name = '"
                                                   + nomineefirstnametextbox2.Text + "', Nominee_Last_Name = '"
                                                   + nomineelastnametextbox2.Text + "', Nominee_DOB = '"
                                                   + dateofBirthCalender2.Text + "', Nominee_Relation = '"
                                                   + relationTextBox2.Text + "' where Nominee_Id = '" + nomineeIdList[1] + "'");
                        dalObject.FunExecuteNonQuery("update nominee_table set Nominee_First_Name = '"
                                                    + nomineefirstnametextbox3.Text + "', Nominee_Last_Name = '"
                                                    + nomineelastnametextbox3.Text + "', Nominee_DOB = '"
                                                    + dateofBirthCalender3.Text + "', Nominee_Relation = '"
                                                    + relationTextBox3.Text + "' where Nominee_Id = '" + nomineeIdList[2] + "'");
                        break;
                }

                messageLabel.Text = "Updation Successful...";

                memberGridView.DataSource = dalObject.FunDataTable("select * from members_profile where Mem_Id = '" + Session["memberId"].ToString() + "'");
                memberGridView.DataBind();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "emailMessage()", true);
            }
        }
    }

    protected void backToSearch_Click(object sender, EventArgs e)
    {
        Response.Redirect("MemberSearch.aspx");
    }

    private bool ValidateEmail(string emailInput)
    {
        using (Claim_Management_System dalObject = new Claim_Management_System())
        {
            SqlDataReader dr = dalObject.FunExecuteReader("select Mem_Email_Id from members_profile where Mem_Email_Id = @username and Mem_Id <> @password", emailInput, Member_Id);

            if (dr.HasRows)
            {
                dr.Close();
                return false;
            }

            dr.Close();

            return true;
        }
    }

    protected void emailTextBox_TextChanged(object sender, EventArgs e)
    {
        if (ValidateEmail(emailTextBox.Text))
        {
            emailValidate = true;
        }
        else
        {
            emailValidate = false;
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "emailMessage()", true);
        }
    }

    protected void cancelButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("MemberSearch.aspx");
    }

    protected void nomineeDeleteButton1_Click(object sender, ImageClickEventArgs e)
    {
        using (Claim_Management_System dalObject = new Claim_Management_System())
        {
            dalObject.FunExecuteNonQuery("delete from nominee_table where nominee_id = '" + nomineeIdList[0] + "'");
            nominee1.Visible = false;
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "deletionMessage()", true);
            Response.Redirect("MemberProfileUpdate.aspx");
        }
    }

    protected void nomineeDeleteButton2_Click(object sender, ImageClickEventArgs e)
    {
        using (Claim_Management_System dalObject = new Claim_Management_System())
        {
            dalObject.FunExecuteNonQuery("delete from nominee_table where nominee_id = '" + nomineeIdList[1] + "'");
            nominee2.Visible = false;
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "deletionMessage()", true);
            Response.Redirect("MemberProfileUpdate.aspx");
        }
    }

    protected void nomineeDeleteButton3_Click(object sender, ImageClickEventArgs e)
    {
        using (Claim_Management_System dalObject = new Claim_Management_System())
        {
            dalObject.FunExecuteNonQuery("delete from nominee_table where nominee_id = '" + nomineeIdList[2] + "'");
            nominee3.Visible = false;
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "deletionMessage()", true);
            Response.Redirect("MemberProfileUpdate.aspx");
        }
    }

    protected void nomineeAddButton_Click(object sender, EventArgs e)
    {
        using (Claim_Management_System dalObject = new Claim_Management_System())
        {
            switch (Convert.ToInt32(nomineecombobox.Text))
            {
                case 1:

                    string lastNomineeId = dalObject.FunExecuteScalar("SELECT TOP 1 nominee_id FROM nominee_table ORDER BY cast(substring(nominee_id, 2, len(Nominee_id) - 1) as int) DESC").ToString();
                    string nominee_Id = "N" + (Convert.ToInt32(lastNomineeId.Substring(1, lastNomineeId.Length - 1)) + 1);
                    nomineeIdList.Add(nominee_Id);

                    nomineecombobox.Text = "2";
                    nominee2.Visible = true;
                    dalObject.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", nominee_Id,
                                                nomineefirstnametextbox2.Text,
                                                nomineelastnametextbox2.Text,
                                                dateofBirthCalender2.Text,
                                                relationTextBox2.Text, Session["memberId"].ToString(), nomineemale2.Checked ? "M" : "F");
                    nomineeDeleteButton1.Visible = true;

                    foreach (Control x in nominee2.Controls)
                    {
                        if (x is TextBox)
                        {
                            ((TextBox)x).Text = "";
                        }
                    }

                    break;
                case 2:
                    string lastNomineeId1 = dalObject.FunExecuteScalar("SELECT TOP 1 nominee_id FROM nominee_table ORDER BY cast(substring(nominee_id, 2, len(Nominee_id) - 1) as int) DESC").ToString();
                    string nominee_Id1 = "N" + (Convert.ToInt32(lastNomineeId1.Substring(1, lastNomineeId1.Length - 1)) + 1);
                    nomineeIdList.Add(nominee_Id1);

                    nomineecombobox.Text = "3";
                    nominee3.Visible = true;
                    dalObject.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", nominee_Id1,
                                                nomineefirstnametextbox3.Text,
                                                nomineelastnametextbox3.Text,
                                                dateofBirthCalender3.Text,
                                                relationTextBox3.Text, Session["memberId"].ToString(), nomineemale3.Checked ? "M" : "F");

                    foreach (Control x in nominee3.Controls)
                    {
                        if (x is TextBox)
                        {
                            ((TextBox)x).Text = "";
                        }
                    }

                    break;
            }
        }
    }
}