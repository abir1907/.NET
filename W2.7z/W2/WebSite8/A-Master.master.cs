﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CMS_Project;
public partial class A_Master : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Admin_Id"] != null)
        {
            Label1.Text = Session["Admin_Id"].ToString();
        }        
        else
            Response.Redirect("login.aspx");
    }
    protected void Logout_Click(object sender, ImageClickEventArgs e)
    {
        Session.Abandon();
        Response.Redirect("login.aspx");
    }
}
