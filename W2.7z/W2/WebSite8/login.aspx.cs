﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using CMS_Project;
public partial class login : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void LoginControl_Authenticate(object sender, AuthenticateEventArgs e)
    {           
    }
    protected void LoginButton_Click(object sender, EventArgs e)
    {        
        using (Claim_Management_System da = new Claim_Management_System())
        {
            string Admin_First_Name = String.Empty;
            string Admin_Id = String.Empty;
            string cmd;
            cmd = "exec usp_login '" + LoginControl.UserName + "','" + LoginControl.Password + "'";
            SqlDataReader dr = da.FunExecuteReader(cmd);
            if (dr.Read())
            {
                Admin_Id = dr[0].ToString();
                Admin_First_Name = dr[1].ToString();
                Session["Admin_First_Name"] = Admin_First_Name;
                Session["Admin_Id"] = Admin_Id;
                Response.Redirect("Default3.aspx");
            }
        }
    }
}