﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using CMS_Project;
using BLL_ClaimRequest;

public partial class MemberClaimRequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Admin_Id"] == null)
        {
            Response.Redirect("login.aspx");
        }
        adminidtextbox.Text = Session["Admin_Id"].ToString();
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();
            ds.ReadXml(Server.MapPath("App_Data/ClaimReasons.xml"));
            reasonComboBox.DataSource = ds.Tables[0];
            reasonComboBox.DataTextField = "name";
            reasonComboBox.DataBind();
        }
    }
    protected void memberidtextbox_TextChanged(object sender, EventArgs e)
    {
        using(BLL_Claim bc = new BLL_Claim())
        {
            List<string> li = new List<string>();
            li = bc.ClaimRequestAutofill(memberidtextbox.Text);
            if (li.Count != 0)
            {
                firstNameTextBox.Text = li[0];
                lastNameTextBox.Text = li[1];
                nomineeTextBox.Text = li[2];
                insuranceTextBox.Text = li[3];
                maxinsurancetextbox.Text = li[4];
            }
            else
            {
                firstNameTextBox.Text = null;
                lastNameTextBox.Text = null;
                nomineeTextBox.Text = null;
                insuranceTextBox.Text = null;
                maxinsurancetextbox.Text = null;
            }
        }
    }
    protected void submitButton_Click(object sender, EventArgs e)
    {
        using(BLL_Claim bc = new BLL_Claim())
        {
            if (ReqDateCalender.Text == null)
            {
                Response.Write("<script>alert('Please select request date!')</script>");
            }
            int result = bc.RegisterNewClaim(memberidtextbox.Text, ReqDateCalender.Text, reasonComboBox.SelectedItem.Text,
                                                 maxinsurancetextbox.Text);
            {
                if (result == -1)
                {
                    Response.Write("<script>alert('Request date must be today!')</script>");
                }
                else if (result == 1)
                {
                    Response.Write("<script>alert('Claim Succesfuly Registered!')</script>");
                }
                else
                {
                    Response.Write("<script>alert('Claim Registration failed!')</script>");
                }
            }
        }
    }
}