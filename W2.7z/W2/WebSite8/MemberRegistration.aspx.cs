﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using CMS_Project;
using BLL_ClaimRequest;

public partial class MemberRegistration : System.Web.UI.Page
{
    #region Variables
    DataTable dt;
    int rowcount, rowcountMemberTable;
    string  gender, cmd, cmd_1, incId, cmd_3, cmd_4;
    SqlDataReader sdr;
    SqlDataAdapter dadapter;
    #endregion
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Admin_Id"] == null)
        {
            Response.Redirect("login.aspx");
        }
        using (Claim_Management_System da = new Claim_Management_System())
        {
            using (BLL_Claim bll = new BLL_Claim())
            {
                adminidtextbox.Text = Session["Admin_Id"].ToString();
                #region code for auto increment Member Id
                memberidtextbox.Text = bll.MemberIdGeneration();
                nominee1.Visible = true;
                #endregion
            }           
        }
    }

    protected void nomineecombobox_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region Combobox
        if (nomineecombobox.Text.Equals("1"))
        {
            nominee1.Visible = true;
            nominee2.Visible = false;
            nominee3.Visible = false;

        }
        else if (nomineecombobox.Text.Equals("2"))
        {
            nominee1.Visible = true;
            nominee2.Visible = true;
            nominee3.Visible = false;
        }
        else if (nomineecombobox.Text.Equals("3"))
        {
            nominee1.Visible = true;
            nominee2.Visible = true;
            nominee3.Visible = true;
        }
        #endregion        
    }
    
    protected void addmemberButton_Click(object sender, EventArgs e)
    {
        using (Claim_Management_System da = new Claim_Management_System())
        {
            using (BLL_Claim bll = new BLL_Claim())
            {
                #region Member insertion
                cmd_1 = "exec usp_selectInsTypeId '" + insurancecombobox.SelectedItem.Text + "'";
                incId = (string)da.FunExecuteScalar(cmd_1);

                rowcount = da.FunMemberInsertion("usp_meminsert",
                    memberidtextbox.Text, firstNameTextBox.Text, lastNameTextBox.Text, dateOfBirthCalender.Text, (Male.Checked) ? "M" : "F", "Indian", addressTextArea.Text, phoneTextBox.Text,
                    emailTextBox.Text, nomineecombobox.SelectedValue, adminidtextbox.Text, incId);
                #endregion

                #region Nominee Table
                string nc = "";
                switch (nomineecombobox.Text)
                {
                    case "1":
                        nc = bll.NomineeIdGeneration();
                        da.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", nc,
                                                    nomineefirstnametextbox1.Text,
                                                    nomineelastnametextbox1.Text,
                                                    dateofBirthCalender1.Text,
                                                    relationTextBox1.Text, memberidtextbox.Text, nomineemale1.Checked ? "M" : "F");
                        break;
                    case "2":
                        nc = bll.NomineeIdGeneration();
                        da.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", nc,
                                                    nomineefirstnametextbox1.Text,
                                                    nomineelastnametextbox1.Text,
                                                    dateofBirthCalender1.Text,
                                                    relationTextBox1.Text, memberidtextbox.Text, nomineemale1.Checked ? "M" : "F");
                        nc = bll.NomineeIdGeneration();
                        da.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", nc,
                                                    nomineefirstnametextbox2.Text,
                                                    nomineelastnametextbox2.Text,
                                                    dateofBirthCalender2.Text,
                                                    relationTextBox2.Text, memberidtextbox.Text, nomineemale1.Checked ? "M" : "F");
                        break;
                    case "3":
                        nc = bll.NomineeIdGeneration();
                        da.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", nc,
                                                    nomineefirstnametextbox1.Text,
                                                    nomineelastnametextbox1.Text,
                                                    dateofBirthCalender1.Text,
                                                    relationTextBox1.Text, memberidtextbox.Text, nomineemale1.Checked ? "M" : "F");
                        nc = bll.NomineeIdGeneration();
                        da.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", nc,
                                                    nomineefirstnametextbox2.Text,
                                                    nomineelastnametextbox2.Text,
                                                    dateofBirthCalender2.Text,
                                                    relationTextBox2.Text, memberidtextbox.Text, nomineemale1.Checked ? "M" : "F");
                        nc = bll.NomineeIdGeneration();
                        da.Funinsertnominee("exec usp_nomineeinsert @id,@fname,@lname,@dob,@relation,@mid,@gen", nc,
                                                    nomineefirstnametextbox3.Text,
                                                    nomineelastnametextbox3.Text,
                                                    dateofBirthCalender3.Text,
                                                    relationTextBox3.Text, memberidtextbox.Text, nomineemale1.Checked ? "M" : "F");
                        break;
                }
                #endregion
            }
            #region Gridview Databind
            if (rowcount > 0)
            {
                RegistrationPanel.Visible = false;
                Nominee.Visible = false;
                InsurancePanel.Visible = false;
                dt = da.FunDataTable("exec usp_memberDetails '" + memberidtextbox.Text + "'");
                messageLabel.Text = string.Empty;
                MemberGridView.Visible = true;
                MemberGridView.AutoGenerateRows = true;
                MemberGridView.DataSource = dt;
                MemberGridView.DataBind();
                messageLabel.Text = "Registration Successful";
            }
            else
            {
                messageLabel.Text = "Error Occured ! Try again ...";
            }
            #endregion
        }
    }
    
    protected void insurancecombobox_SelectedIndexChanged(object sender, EventArgs e)
    {
        using (Claim_Management_System da = new Claim_Management_System())
        {
            #region autofill insurance details textbox
            if (insurancecombobox.SelectedIndex > 0)
            {
                dt = da.FunDataTable("exec usp_selectInsDetails '" + insurancecombobox.SelectedItem.Text + "'");
                insuredtextbox.Text = dt.Rows[0][2].ToString();
                maxinsurancetextbox.Text = dt.Rows[0][3].ToString();
            }
            else
            {
                insuredtextbox.Text = string.Empty;
                maxinsurancetextbox.Text = string.Empty;
            }
            #endregion
        }
    }

    #region Reset method for Cancel button
    public void reset()
    {
        foreach (Control x in RegistrationPanel.Controls)
        {
            if (x is TextBox && !(x.ID.ToString().Equals("adminidtextbox") || x.ID.ToString().Equals("memberidtextbox")))
            {
                ((TextBox)x).Text = "";
            }
        }
        foreach (Control x in nominee1.Controls)
        {
            if (x is TextBox)
            {
                ((TextBox)x).Text = "";
            }
        }

        foreach (Control x in nominee2.Controls)
        {
            if (x is TextBox)
            {
                ((TextBox)x).Text = "";
            }
        }

        foreach (Control x in nominee3.Controls)
        {
            if (x is TextBox)
            {
                ((TextBox)x).Text = "";
            }
        }
    }
    #endregion    
    protected void cancelButton_Click(object sender, EventArgs e)
    {
        reset();
    }
    
}