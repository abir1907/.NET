﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
                                
    }
    protected void insert_button_Click(object sender, EventArgs e)
    {
        DataAccess obj = new DataAccess();
        string cmd1 = "select * from studentdetails where Roll_Number='" + roll.Text + "'";
        SqlDataReader dr = obj.FunExecuteReader(cmd1);

        string cmd="insert into StudentDetails values('"+roll.Text+"','"+name.Text+"','"+address.Text+"')";
        
        int insert = obj.FunExecuteNonQuery(cmd);
        if (insert > 0)
        {
            Response.Write("Row inserted");
        }
        else
        {
            Response.Write("Already exists");
        }
    }
    protected void update_button_Click(object sender, EventArgs e)
    {
        DataAccess obj = new DataAccess();
        string cmd = "update StudentDetails set address='" + address.Text + "'";

        int insert = obj.FunExecuteNonQuery(cmd);
        if (insert > 0)
        {
            Response.Write("Row inserted");
        }
        else
        {
            Response.Write("Already exists");
        }
    }
}