﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    DataClassesDataContext db = new DataClassesDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            show();
        }
    }
    public void show()
    {
        var a = from c in db.employeeinfos
                select c;
        GridView1.DataSource = a.ToList();
        GridView1.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        /*
        employeeinfo em = new employeeinfo();
        em.emp_id = int.Parse(ID.Text);
        em.emp_name = NAME.Text;
        em.emp_salary = long.Parse(SALARY.Text);
        em.emp_address = ADDRESS.Text;

        db.employeeinfos.InsertOnSubmit(em);
        db.SubmitChanges();
        show();
        Response.Write("Record inserted");*/
        db.usp_insert(int.Parse(ID.Text), NAME.Text, long.Parse(SALARY.Text), ADDRESS.Text);
        show();
    }
}