﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
    
    SqlConnection con = new SqlConnection(@"server=PC189961\MSSQLSERVER2008;database=sdfdf;integrated security=true");
    SqlCommand cmd;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        string pass = FormsAuthentication.HashPasswordForStoringInConfigFile(Login1.Password, "MD5");
        con.Open();
        cmd = new SqlCommand("select username,password from loginuser where username=@user and password=@pwd");
        cmd.Parameters.AddWithValue("@user",Login1.UserName);
        cmd.Parameters.AddWithValue("@pwd",pass);
        dr=cmd.ExecuteReader();
        if(dr.Read())
        {
            FormsAuthentication.RedirectFromLoginPage(Login1.UserName,Login1.RememberMeSet);
        }
       
    }
}